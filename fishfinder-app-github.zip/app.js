/* global L */
function monthFromInput(value) {
  if (!value) return (new Date()).getMonth() + 1;
  return parseInt(value.split('-')[1], 10);
}

const map = L.map('map', { zoomControl: true });
map.setView([-27.25, 153.2], 10);

const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18,
  attribution: '&copy; OpenStreetMap'
}).addTo(map);

const seamarks = L.tileLayer('https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png', {
  maxZoom: 18,
  opacity: 0.85,
  attribution: '&copy; OpenSeaMap contributors'
}).addTo(map);

const depthLayer = L.tileLayer('https://tiles.openseamap.org/depth/{z}/{x}/{y}.png', {
  maxZoom: 17,
  opacity: 0.55,
  attribution: '&copy; OpenSeaMap bathymetry (not for navigation)'
}).addTo(map);

L.control.layers(
  { 'OpenStreetMap': osm },
  { 'Seamarks': seamarks, 'Depth contours (demo)': depthLayer },
  { collapsed: true }
).addTo(map);

let SPECIES = {};
let FEATURES = null;
let heat = null;
let spotsLayer = null;

Promise.all([
  fetch('data/species.json').then(r => r.json()),
  fetch('data/features.geojson').then(r => r.json())
]).then(([species, features]) => {
  SPECIES = species;
  FEATURES = features;
  populateSpecies(species);
  recalc();
});

function populateSpecies(species) {
  const sel = document.getElementById('species');
  Object.keys(species).forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = species[key].name;
    sel.appendChild(opt);
  });
  sel.value = Object.keys(species)[0];
}

function currentInputs() {
  return {
    speciesKey: document.getElementById('species').value,
    month: monthFromInput(document.getElementById('season').value),
    tide: document.getElementById('tide').value,
    tod: document.getElementById('timeofday').value,
    showSpots: document.getElementById('showSpots').checked
  };
}

function scoreFeature(species, f, inputs) {
  let s = 0;
  if (species.habitats && f.properties.habitat) {
    if (species.habitats.includes(f.properties.habitat)) s += 3; else s -= 1;
  }
  if (species.depth) {
    const d = f.properties.depth_m;
    if (d != null) {
      const [minD, maxD] = species.depth;
      if (d >= minD && d <= maxD) s += 2; else s -= 1;
    }
  }
  if (species.tidePrefs && inputs.tide) {
    if (species.tidePrefs.includes(inputs.tide)) s += 2;
  }
  if (species.timeOfDay && inputs.tod) {
    if (species.timeOfDay.includes(inputs.tod)) s += 1.5;
  }
  if (species.seasonMonths && inputs.month) {
    if (species.seasonMonths.includes(inputs.month)) s += 2;
    else s -= 0.5;
  }
  if (f.properties.structure && species.structureBonus) {
    if (species.structureBonus.includes(f.properties.structure)) s += 1.5;
  }
  if (species.currentKnots && f.properties.current_kn) {
    const [minK, maxK] = species.currentKnots;
    if (f.properties.current_kn >= minK && f.properties.current_kn <= maxK) s += 1;
  }
  return s;
}

function recalc() {
  if (!FEATURES || !SPECIES) return;
  const inputs = currentInputs();
  const species = SPECIES[inputs.speciesKey];

  const points = [];
  const spotMarkers = [];

  FEATURES.features.forEach(f => {
    const s = scoreFeature(species, f, inputs);
    const coords = f.geometry.coordinates;
    if (typeof coords[0] === 'number') {
      const lat = coords[1], lng = coords[0];
      const intensity = Math.max(0, s);
      if (intensity > 0) points.push([lat, lng, intensity]);
      if (inputs.showSpots && intensity >= 4) {
        const m = L.circleMarker([lat, lng], { radius: 6, weight: 1 });
        m.bindPopup(renderPopup(species, f, s));
        spotMarkers.push(m);
      }
    }
  });

  if (heat) heat.remove();
  if (spotsLayer) spotsLayer.remove();

  heat = L.heatLayer(points, { radius: 28, blur: 18, maxZoom: 13, minOpacity: 0.2 }).addTo(map);
  spotsLayer = L.layerGroup(spotMarkers).addTo(map);
}

function renderPopup(species, f, score) {
  const p = f.properties || {};
  return `
    <div class="popup">
      <div><strong>${species.name}</strong> — score ${score.toFixed(1)}</div>
      <div><em>${p.name || p.habitat || 'Unnamed feature'}</em></div>
      <div>Habitat: ${p.habitat || 'n/a'} | Structure: ${p.structure || 'n/a'} | Depth: ${p.depth_m ?? 'n/a'} m</div>
      <div>Current: ${p.current_kn ?? 'n/a'} kn</div>
    </div>
  `;
}

['species','season','tide','timeofday','showSpots'].forEach(id => {
  document.getElementById(id).addEventListener('change', recalc);
});
